## ERPNext includes these public works

For Frappe Framework, please see attributions.md at https://github.com/frappe/frappe/

#### Images

POS Icon: https://thenounproject.com/icon/41958 by hunotika
