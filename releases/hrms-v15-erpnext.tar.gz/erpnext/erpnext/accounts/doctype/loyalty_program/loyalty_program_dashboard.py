def get_data():
	return {
		"fieldname": "loyalty_program",
		"transactions": [{"items": ["Sales Invoice", "Customer"]}],
	}
