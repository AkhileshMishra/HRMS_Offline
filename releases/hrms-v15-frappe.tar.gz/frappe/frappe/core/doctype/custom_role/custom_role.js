// Copyright (c) 2016, Frappe Technologies and contributors
// For license information, please see license.txt

frappe.ui.form.on("Custom Role", {
	refresh: function (frm) {},
});
