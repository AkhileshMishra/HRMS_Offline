# Copyright (c) 2020, Frappe Technologies and Contributors
# License: MIT. See LICENSE
# import frappe
import unittest


class TestPaytmSettings(unittest.TestCase):
	pass
