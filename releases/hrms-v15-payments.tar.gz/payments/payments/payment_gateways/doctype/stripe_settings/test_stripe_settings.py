# Copyright (c) 2018, Frappe Technologies and Contributors
# License: MIT. See LICENSE
import unittest


class TestStripeSettings(unittest.TestCase):
	pass
