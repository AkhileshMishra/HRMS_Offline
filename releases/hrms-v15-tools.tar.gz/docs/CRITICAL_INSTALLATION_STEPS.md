# CRITICAL INSTALLATION STEPS - HRMS v15 Offline Bundle

## 🚨 IMPORTANT: Yarn Offline Mirror Setup for Bench

### The Issue
When `bench get-app` clones applications into `BENCH_HOME/apps/<app>`, the relative paths in `.yarnrc` files (e.g., `../../npm-offline`) resolve to `BENCH_HOME/npm-offline` — NOT the bundle's `npm-offline` directory. This can cause build failures.

### The Solution: Belt-and-Suspenders Approach

Add these commands **after `bench init` and before `bench build`**:

```bash
# 1. Make the offline mirror visible at the bench root for relative .yarnrc
ln -sfn "$BUNDLE_DIR/npm-offline" "$BENCH_HOME/npm-offline"

# 2. Force-set each cloned app to use that mirror (works even if .yarnrc is relative)
for app in "$BENCH_HOME/apps/frappe" "$BENCH_HOME/apps/erpnext" "$BENCH_HOME/apps/hrms"; do
  ( cd "$app" && yarn config set yarn-offline-mirror "$BENCH_HOME/npm-offline" >/dev/null 2>&1 || true )
done

# 3. Avoid hangs if anything ever tries to reach out
export YARN_CACHE_FOLDER="$BENCH_HOME/npm-offline"
yarn config set network-timeout 1 >/dev/null 2>&1 || true
```

### Why This Works
- **Symlink**: Satisfies the relative `.yarnrc` entries in the bundle
- **Post-clone Override**: Makes the mirror explicit for the bench copies
- **Network Timeout**: Prevents hanging if any process tries to reach the internet

---

## 📋 Complete Installation Sequence

### 1. Extract Bundle
```bash
tar -xzf hrms-offline-bundle-fixed.tar.gz
cd hrms-offline-bundle
export BUNDLE_DIR="$(pwd)"
```

### 2. Set Up Local APT Repository
```bash
# Add local repository
echo "deb [trusted=yes] file://$BUNDLE_DIR/debs ./" | sudo tee /etc/apt/sources.list.d/hrms-offline.list
sudo apt-get update

# Install system packages
sudo apt-get install -y git python3 python3-venv python3-dev python3-pip build-essential \
  libffi-dev libssl-dev libmysqlclient-dev mariadb-server redis-server nginx \
  xfonts-75dpi xfonts-base wkhtmltopdf
```

### 3. Configure MariaDB (BEFORE creating sites)
```bash
sudo tee -a /etc/mysql/my.cnf >/dev/null <<'EOF'
[mysqld]
character-set-client-handshake = FALSE
character-set-server = utf8mb4
collation-server = utf8mb4_unicode_ci

[mysql]
default-character-set = utf8mb4
EOF

sudo systemctl restart mariadb
```

### 4. Set Up Python Environment
```bash
# Install frappe-bench
pip3 install --no-index --find-links "$BUNDLE_DIR/wheels" frappe-bench

# Configure pip for offline use
mkdir -p ~/.pip
cat > ~/.pip/pip.conf << EOF
[global]
no-index = true
find-links = $BUNDLE_DIR/wheels
EOF
```

### 5. Initialize Bench
```bash
# Create bench
bench init frappe-bench --frappe-path "$BUNDLE_DIR/repos/frappe" --skip-assets

cd frappe-bench
export BENCH_HOME="$(pwd)"

# Configure pip for this bench
echo -e "[pip]\nno-index = true\nfind-links = $BUNDLE_DIR/wheels" > pip.conf
bench set-config -g pip_conf "$(pwd)/pip.conf"
```

### 6. **CRITICAL: Set Up Yarn Offline Mirror**
```bash
# Create symlink for relative .yarnrc paths
ln -sfn "$BUNDLE_DIR/npm-offline" "$BENCH_HOME/npm-offline"

# Get applications
bench get-app "$BUNDLE_DIR/repos/erpnext"
bench get-app "$BUNDLE_DIR/repos/hrms"
bench get-app "$BUNDLE_DIR/repos/payments"  # if included

# Force-configure each app's yarn mirror (belt-and-suspenders)
for app in "$BENCH_HOME/apps/frappe" "$BENCH_HOME/apps/erpnext" "$BENCH_HOME/apps/hrms"; do
  ( cd "$app" && yarn config set yarn-offline-mirror "$BENCH_HOME/npm-offline" >/dev/null 2>&1 || true )
done

# Set offline environment
export YARN_CACHE_FOLDER="$BENCH_HOME/npm-offline"
yarn config set network-timeout 1 >/dev/null 2>&1 || true
```

### 7. Create Site and Install Apps
```bash
# Create new site
bench new-site site1.local --admin-password admin --mariadb-root-password root

# Install applications
bench --site site1.local install-app erpnext
bench --site site1.local install-app hrms
# bench --site site1.local install-app payments  # if included

# Build assets (should use offline mirror)
bench build
```

---

## 🔍 Verification Steps

### Test wkhtmltopdf
```bash
# Test PDF generation
bench --site site1.local execute "frappe.utils.print_format.download_pdf('User', 'Administrator', 'Standard')"
```

### Verify Offline Operation
```bash
# Disconnect from internet and try:
bench build --force
# Should complete without network access
```

### Check Database Charset
```bash
mysql -u root -p -e "SHOW VARIABLES LIKE 'character_set%';"
# Should show utf8mb4 for all relevant variables
```

---

## 🚨 Troubleshooting

**If yarn fails to find packages:**
1. Verify symlink: `ls -la $BENCH_HOME/npm-offline`
2. Check app configs: `cat apps/frappe/.yarnrc`
3. Re-run the yarn config commands above

**If pip fails to find packages:**
1. Check pip.conf: `cat ~/.pip/pip.conf`
2. Verify wheels directory: `ls $BUNDLE_DIR/wheels/`

**If MariaDB has charset issues:**
1. Verify my.cnf was updated: `sudo cat /etc/mysql/my.cnf | tail -10`
2. Restart MariaDB: `sudo systemctl restart mariadb`
3. Check variables: `mysql -u root -p -e "SHOW VARIABLES LIKE 'character_set%';"`

This approach ensures robust offline installation regardless of network conditions or path configurations.

