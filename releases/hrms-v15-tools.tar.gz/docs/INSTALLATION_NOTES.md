# HRMS v15 Offline Bundle - Installation Notes

## Pre-installation Setup

### 1. MariaDB Character Set Configuration
Before creating any sites, add the charset configuration to MariaDB:

```bash
sudo tee -a /etc/mysql/my.cnf >/dev/null <<'CHARSET_EOF'
[mysqld]
character-set-client-handshake = FALSE
character-set-server = utf8mb4
collation-server = utf8mb4_unicode_ci

[mysql]
default-character-set = utf8mb4
CHARSET_EOF

sudo systemctl restart mariadb
```

### 2. Pip Configuration for Offline Installation
Configure bench to use the offline wheelhouse:

```bash
# In your bench directory
echo -e "[pip]\nno-index = true\nfind-links = $(pwd)/../wheels" > pip.conf
bench set-config -g pip_conf "$(pwd)/pip.conf"
```

### 3. Yarn Offline Mirror Setup
**CRITICAL**: The .yarnrc files use relative paths that resolve to `BENCH_HOME/npm-offline`. You MUST create a symlink and configure each app:

```bash
# After bench init, before bench build:
ln -sfn "$BUNDLE_DIR/npm-offline" "$BENCH_HOME/npm-offline"

# Force-configure each app (belt-and-suspenders approach)
for app in "$BENCH_HOME/apps/frappe" "$BENCH_HOME/apps/erpnext" "$BENCH_HOME/apps/hrms"; do
  ( cd "$app" && yarn config set yarn-offline-mirror "$BENCH_HOME/npm-offline" >/dev/null 2>&1 || true )
done

# Set offline environment
export YARN_CACHE_FOLDER="$BENCH_HOME/npm-offline"
yarn config set network-timeout 1 >/dev/null 2>&1 || true
```

**See CRITICAL_INSTALLATION_STEPS.md for complete sequence.**

## Installation Process

1. Extract the bundle: `tar -xzf hrms-offline-bundle.tar.gz`
2. Set up local APT repository (see main documentation)
3. Install system packages from local repository
4. Install Python packages from wheels directory
5. Set up bench with offline configuration
6. Build applications using offline mirrors

## Troubleshooting

- If Yarn fails to find packages, ensure the npm-offline directory is accessible
- If pip fails to find packages, check the pip.conf configuration
- If MariaDB has charset issues, verify the my.cnf configuration was applied
