# Versions & Pins
OS: Ubuntu 22.04.5 LTS
Generated: 2025-09-16T08:49:45Z

## Git commits
frappe: 1c9ae01384762d809e5a05662d999eda2adc6cb8
erpnext: ceb17b6b614d64ad3369dec9f24e9747176b620a
hrms: fafe5905631a2bf89be05ddff71670d7dc0540c3
payments: a682448a63d59ecf9288cfafa29cdad215ddf0ff

## Tools
Node: v18.20.4 (tarball saved)
Yarn: v1.22.19 (standalone .cjs saved)

